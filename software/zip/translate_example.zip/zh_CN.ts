<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_SG">
<context>
    <name>Dialog</name>
    <message numerus="yes">
        <location filename="dialogui.py" line="31"/>
        <source>Dialog</source>
        <translation type="unfinished">
            <numerusform>对话框</numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="dialogui.py" line="32"/>
        <source>variable one</source>
        <translation type="unfinished">
            <numerusform>参数一</numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="dialogui.py" line="33"/>
        <source>variable two</source>
        <translation type="unfinished">
            <numerusform>参数二</numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="dialogui.py" line="34"/>
        <source>variable three</source>
        <translation type="unfinished">
            <numerusform>参数三</numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message numerus="yes">
        <location filename="mainui.py" line="50"/>
        <source>MainWindow</source>
        <translation type="unfinished">
            <numerusform>主窗口</numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="mainui.py" line="51"/>
        <source>This is the main window</source>
        <translation type="unfinished">
            <numerusform>这是主窗口</numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="mainui.py" line="52"/>
        <source>Used for test</source>
        <translation type="unfinished">
            <numerusform>测试使用</numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="mainui.py" line="53"/>
        <source>Option</source>
        <translation type="unfinished">
            <numerusform>选项</numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="mainui.py" line="54"/>
        <source>Language</source>
        <translation type="unfinished">
            <numerusform>语言</numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="mainui.py" line="55"/>
        <source>Configure</source>
        <translation type="unfinished">
            <numerusform>配置</numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="mainui.py" line="56"/>
        <source>Chinese</source>
        <translation type="unfinished">
            <numerusform>中文</numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
</context>
</TS>
