-- Удаляем таблицы.
DROP TABLE "About" ;
DROP TABLE "Settings" ;
DROP TABLE "Hotkey" ;
DROP TABLE "Autorun" ;
DROP TABLE "Alerts" ;
DROP TABLE "User" ;