-- Update data in the ABOUT table.
UPDATE "About" 
SET (ProgramVersion, WebSite, Email, Copyright, UrlPrivacyPolicy) 
= ('v.2022.04.18', 'controlmictray.pp.ua', 'i@controlmictray.pp.ua', 'Copyright © 2022\nSimonovskiy & Lastivka\nAll rights reserved', 'https://controlmictray.pp.ua/PrivacyPolicy.html');